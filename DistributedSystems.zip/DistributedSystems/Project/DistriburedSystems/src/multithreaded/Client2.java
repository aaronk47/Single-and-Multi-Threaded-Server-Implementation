package multithreaded;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Scanner;

public class Client2 {
	private static String LocOfDirectory="C:/Users/Lord Aaron/Desktop/Client";
	static Socket socket =null;
	static DataInputStream DIS = null;
	static DataOutputStream DOS= null;
	
	public static void main(String args[]) throws Exception{
	
		int option;
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));	
		try {
			socket= new Socket("localhost",8080);
		}catch(Exception e){
			System.out.println("Connection Refused");

}
		DIS = new DataInputStream(socket.getInputStream());
		DOS= new DataOutputStream(socket.getOutputStream());
		String ID = "Client2";
		DOS.writeUTF(ID);
		System.out.println("Connection Established");
		DOS.writeUTF("Show Directory");
		
		LocOfDirectory=DIS.readUTF();
		String ListofDirectory = DIS.readUTF();
		System.out.println("Current Location"+ LocOfDirectory);
		ListofDirectory=ListofDirectory.replaceAll("\\\\","/");
		System.out.println("List of Directories is as follow:"+ ListofDirectory);
		
		do {
			
			System.out.println("Enter The option you want to execute \n 1.upload \n 2.Download \n 3.Rename \n 4.Delete \n 5.Close Connection");
			option=Integer.parseInt(br.readLine());
			
			switch(option) {
			case 1:fileupload();
					break;
			case 2:fileDownload();
					break;
				
			case 3:fileRename();
					break;
			case 4:fileDelete();
					break;
			
						
			case 5:System.out.println("Terrmination Successful");
					DOS.writeUTF("Terminate");
			case 6:calculate_pi();
				break;
			case 7: addition();
				break;
			case 8:sort();
				break;
			case 9: matrix_multiplication();
				break;
			default: System.out.println("Invalid Input");
				
			
			}
		}while(option!=5);
		socket.close();
		DIS.close();
		DOS.close();
		
		}
//user sends the command
//server responds with the list of directories
//user chooses the file to delete and sends name to server
//server sees the response and sends the file to client
	private static void fileDownload() throws IOException {
		String command = "Download";
		DOS.writeUTF(command);
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		String DownloadLocation="";
		String ListofDirectory = DIS.readUTF();
		
		System.out.println("Choose the filename to be downloaded:"+ ListofDirectory);
		System.out.println("Enter the filename to be downloaded");
		String filename = bf.readLine();
		System.out.println("Enter the location to save the file:");
		DownloadLocation= bf.readLine();
		
		
		DOS.writeUTF(filename);
		String Res= DIS.readUTF();
		byte[] b = Res.getBytes("UTF-8");
		File newfile = new File(DownloadLocation+"//"+filename);
		if(!newfile.exists()) {
			FileOutputStream fos= new FileOutputStream(newfile);
			fos.write(b);
			
			fos.flush();
			fos.close();
			System.out.println(filename+" downloaded Successfully!");
		}
		else {
			System.out.println("Already Exists");
		}
		
		
	}

	private static void fileDelete() throws IOException {
		String command="Delete";
		DOS.writeUTF(command);
		BufferedReader bf =new BufferedReader(new InputStreamReader(System.in));
		String Deletefile="";
		String List = DIS.readUTF();
		System.out.println("The List is:"+List);
		System.out.println("Name the file to be deleted");
		Deletefile=bf.readLine();
		
		DOS.writeUTF(Deletefile);
		
		String res=DIS.readUTF();
		System.out.println(res);
	}

	private static void fileRename() throws IOException {
		String command = "Rename";
		DOS.writeUTF(command);
		BufferedReader b =new BufferedReader(new InputStreamReader(System.in));
		String newname="",filename="";
		String ListofDirectory=DIS.readUTF();
		System.out.println("The list of files is:"+ListofDirectory);
		System.out.println("Enter the file to be renamed");
		filename=b.readLine();
		DOS.writeUTF(filename);
		System.out.println("Enter the new name of file");
		newname=b.readLine();
		
		
		DOS.writeUTF(newname);
		String res = DIS.readUTF();
		System.out.println(res);
		
		
		
	}

	private static void fileupload() throws IOException {
		String command = "UPLOAD";
		DOS.writeUTF(command);
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		String source="";
		System.out.println("ENTER THE SOURCE OF FILE:");
		source=bfr.readLine();
		String fileName = source.substring(source.lastIndexOf('/')+1, source.length());
		File file= new File(source);
		if(file.exists()) {
		FileInputStream fis=new FileInputStream(file);
		byte b[]=new byte[(int) file.length()];
		fis.read(b);
		String s =new String(b);
		DOS.writeUTF(fileName + ":"+s);
		
		fis.close();
		}else {
			System.out.println("Not Exists");
		}
	}private static void matrix_multiplication() throws IOException {
	
		Scanner sc=new Scanner(System.in);
		String command="matrix_multiplication";
		DOS.writeUTF(command);
		

		
		int i,j = 0;
		//OutputStream os=socket.getOutputStream();
		//InputStream is=socket.getInputStream();
		//ObjectOutputStream OOS=new ObjectOutputStream(os);
		//ObjectInputStream OIS=new ObjectInputStream(is);
		System.out.println("Enter the base of the matrix:");
		int n=sc.nextInt();
		DOS.writeInt(n);
		int a[][]=new int[n][n];
		int b[][]=new int[n][n];
		int c[][]=new int[n][n];
		//StringBuilder sb=new StringBuilder(" ");
		System.out.println("Enter the elements of first matrix:");
		for( i=0;i<n;i++) {
			for(j=0;j<n;j++) {
				a[i][j]= sc.nextInt();
				DOS.writeInt(a[i][j]);
				//sb.append(a[i][j]);
				
			}
		}
		System.out.println("Enter the elements of second matrix:");
		for(  i=0;i<n;i++) {
			for(j=0;j<n;j++) {
				b[i][j]= sc.nextInt();
			DOS.writeInt(a[i][j]);
				//sb.append(a[i][j]);
				
			}
			
		}
		for(i=0;i<n;i++) {
			for(j=0;j<n;j++) {
				c[i][j]=DIS.readInt();
				System.out.println(c[i][j]+" ");
			}
			System.out.println();
		}
}
		
		
	
		
	
@SuppressWarnings("unused")
private static void sort() throws IOException {
	Scanner sc=new Scanner(System.in);
	String command="Sort";
	DOS.writeUTF(command);
	//OutputStream os=socket.getOutputStream();
	//ObjectOutputStream OOS=new ObjectOutputStream(os);
	System.out.println("Enter the length of an array");
	int n = sc.nextInt();
	StringBuilder sb=new StringBuilder();
	System.out.println("Enter the random number");
	int[] k= new int[n];
	int i;
	for( i=0;i<n;i++) {
		k[i]=sc.nextInt();
		
			sb.append(k[i]+",");
	}
	String str=sb.toString();
	DOS.writeUTF(str);
	//System.out.println("enter if u want ascending or descending");
	//String srt=sc.nextLine();
	//DOS.writeUTF(srt);
	String readingdata=DIS.readUTF();
	
	System.out.println(readingdata);
		
	}
private static void addition() throws IOException {
	Scanner sc=new Scanner(System.in);
	String command="addition";
	DOS.writeUTF(command);
	//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter first value");
	 int i = sc.nextInt();
	DOS.writeInt(i);
	System.out.println("Enter second value");
	int j=sc.nextInt();
	DOS.writeInt(j);
	System.out.println(DIS.readUTF());
	
	
	}
private static void calculate_pi() throws IOException {
	//Scanner sc=new Scanner(System.in);
		String command="calculate_pi";
		DOS.writeUTF(command);
		//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		/*System.out.println("Enter first value");
		float x=sc.nextFloat();
		DOS.writeFloat(x);
		System.out.println("Enter second value");
		float y=sc.nextFloat();
		DOS.writeFloat(y);*/
	System.out.println("The value of pi is");
	//String w=br.readLine();
	//DOS.writeUTF(w);
		System.out.println(DIS.readDouble());
		
		
		
	}}


