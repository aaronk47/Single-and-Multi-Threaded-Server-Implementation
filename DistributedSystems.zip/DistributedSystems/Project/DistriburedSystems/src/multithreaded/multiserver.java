package multithreaded;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;

public class multiserver extends Thread {
	private static String root="C:/Users/Lord Aaron/Desktop/Server";
	public static void main(String args[]) throws Exception{
	BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Server is listening");
	ServerSocket ss= new ServerSocket(8080);
	while(true) {
	Socket s = ss.accept();
	
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					services(s);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		}).start();
	}}
	public static void services(Socket s) throws IOException {
		DataInputStream Dis = new DataInputStream(s.getInputStream());
		DataOutputStream Dos = new DataOutputStream(s.getOutputStream());
		String ID = Dis.readUTF();
		System.out.println("Connection established with:"+ID);
		while(true) {
			String command = Dis.readUTF();
			System.out.println("The Command Received is:"+command);
			if(command.equalsIgnoreCase("Show Directory"))
			{
				
				String dirList = showDirectory(root);
				Dos.writeUTF(root);
				Dos.writeUTF(dirList);
			}else if(command.equalsIgnoreCase("Download")) {
				
				
				String[] fileList = (new File(root)).list();
				StringBuilder files = new StringBuilder("");
				for(String str : fileList) {
					files.append(str+" ");
				}

				Dos.writeUTF(files.toString());
				String temp = Dis.readUTF();
				System.out.println("File to be downloaded is: "+ temp);
				File myFile = new File(root+"//"+temp);
				byte b[] = new byte[(int) myFile.length()];
				FileInputStream fis = new FileInputStream(myFile);
				fis.read(b);
				String response = new String(b,"UTF-8");
				Dos.writeUTF(response);
				System.out.println("File sent to client successfully");
				fis.close();
				
				
			}else if(command.equalsIgnoreCase("Upload")) {
				File file =null;
				//String i = Dis.readUTF();
					//byte[] j=i.getBytes("UTF-8");
					String k1 = Dis.readUTF();
					//String currentLoc = Dis.readUTF();
					String[] response = k1.split(":");
					String fileName = response[0];
					String k = response[1];
					System.out.println("The current location is:"+root);
					System.out.println("The new file is:"+fileName);
					String temp = root.concat("//"+fileName);
					byte[] j = k.getBytes("UTF-8");
					
					file =new File(temp);
					if(file.exists()) {
						
						System.out.println("File Exists");
						
					}else {
						FileOutputStream FOS = new FileOutputStream(file);
						FOS.write(j);
						FOS.close();
						System.out.println("Upload Successful!");
					}
					
					
				
				
			}else if(command.equalsIgnoreCase("Rename")) {
				
				
				String[] fileList = (new File(root)).list();
				StringBuilder files = new StringBuilder("");
				for(String str : fileList) 
					files.append(str+" ");
				
				
				Dos.writeUTF(files.toString());
				
				String oldname=Dis.readUTF();
				String newname=Dis.readUTF();
				File old=new File(root+"//"+oldname);
				File newone=new File(root+"//"+newname);
				if(!(old==newone)) {
				old.renameTo(newone);
				System.out.println("renamed");
				Dos.writeUTF("Sucess");;
				}else {
					System.out.println("same name");
				}
				
					
				
			}else if(command.equalsIgnoreCase("Delete")){
				String[] fileList = (new File(root)).list();
				StringBuilder files = new StringBuilder("");
				for(String str : fileList) 
					files.append(str+" ");
				
				
				Dos.writeUTF(files.toString());
				
				String name=Dis.readUTF();
				File deletefile = new File(root+"//"+name);
				if(deletefile.exists()) {
				deletefile.delete();
				
				Dos.writeUTF("Success");
				}else {
					
					System.out.println("error");
				}
			}else if(command.equalsIgnoreCase("Calculate_pi")) {
				/*float x=Dis.readFloat();
				float y=Dis.readFloat();
				
				float z=x/y;*/
				//Dis.readUTF();
				//Dos.writeFloat((float) (22.0/7.0));
				
				}
			else if(command.equalsIgnoreCase("addition")) {
					int x=Dis.readInt();
					int y=Dis.readInt();
					int z=x+y;
				
					Dos.writeUTF("Answer is:"+ z);
					
				}else if(command.equalsIgnoreCase("Sort")) {
					//char temp;
					String array="";
					String str=Dis.readUTF();
					
					String[] k=str.split(",");
					int[] intarray=new int[k.length];
					StringBuilder sb=new StringBuilder("");
					for(int i=0;i<k.length;i++) {
						intarray[i]=Integer.parseInt(k[i]);
						
					}
			Arrays.sort(intarray);
			
			for(int i=0;i<intarray.length;i++) {
				sb.append(intarray[i]+" ");
				 array = array +Integer.toString(intarray[i]);
				
				 System.out.println(array);
			}
			String string=sb.toString();
			Dos.writeUTF("Sorted array is:"+string);
					
					}else if(command.equalsIgnoreCase("matrix_multiplication")) {
						//OutputStream os=s.getOutputStream();
						//InputStream is=s.getInputStream();
						//ObjectOutputStream OOS=new ObjectOutputStream(os);
						//ObjectInputStream OIS=new ObjectInputStream(is);
						
						int n=Dis.readInt();
						System.out.println("the matrix size is:"+n);
						int i,j=0;
						int[][] a=new int[n][n];
						int[][] b=new int[n][n];
						int[][] c=new int[n][n];
						for(i=0;i<n;i++) {
							for(j=0;j<n;j++) {
								a[i][j]=Dis.readInt();
							
							}
						}
						
						
						for(i=0;i<n;i++) {
							for(j=0;j<n;j++) {
								b[i][j]=Dis.readInt();
								}
					}
						for(i=0;i<n;i++) {
							for(j=0;j<n;j++) {
								for(int k=0;k<n;k++) {
								int sum=0;
								sum +=a[i][k]*b[k][j];
								c[i][j]=sum;
								Dos.writeInt(c[i][j]);
							}
						}
						}
					
					}else if(command.equalsIgnoreCase("Terminate")) {
				break;
			}
		}}
		
	
	
	 static String showDirectory(String root2) {

		String dirList="";
		File FOLDER = new File(root);
		File[] listOfFiles = FOLDER.listFiles();
		
		    for (int i = 0; i < listOfFiles.length; i++) 
		    {

		      if (listOfFiles[i].isFile()) 
		      {
		       dirList= dirList + "File " + listOfFiles[i]+"\n";
		      }
		       else if (listOfFiles[i].isDirectory()) 
		       {
		        dirList= dirList + "Directory " + listOfFiles[i]+"\n";
		      }
		    }
		    return dirList;
	}

}
